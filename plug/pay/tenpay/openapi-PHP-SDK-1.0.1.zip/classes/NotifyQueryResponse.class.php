<?php
//---------------------------------------------------------
//֪ͨ��ѯ��Ӧ
//---------------------------------------------------------
require_once ("common/CommonResponse.class.php");
class NotifyQueryResponse extends CommonResponse{
	
	
}


?>